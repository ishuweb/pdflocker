This is Pdf File Locker Software.
You can lock your file and set a password on it.

STEP 1 : It is not binary package, hence you don't need to install the software
STEP 2 : Just download and extract zipped file in only 'C:/' drive and copy your software
	 from 'dist' folder to anywhere you want.

Click on it and Protect Your Documents.

Designed and Developed by IshuGupta
https://www.github.com/ishuwebdev/pdflockersoft